const box = document.getElementById("box");
const gameArea = document.getElementById("gameArea");
const scoreText = document.getElementById("score");

let score = 0;
let speed = 2;
let y = 0;

// Random X position
function randomX() {
  return Math.random() * (gameArea.clientWidth - 50);
}

// Game loop
function gameLoop() {
  y += speed;
  box.style.top = y + "px";

  if (y > gameArea.clientHeight) {
    alert("Game Over! Your score: " + score);
    location.reload();
  }

  requestAnimationFrame(gameLoop);
}

// Click box
box.addEventListener("click", () => {
  score++;
  scoreText.textContent = score;
  y = 0;
  speed += 0.5;
  box.style.left = randomX() + "px";
});

// Start game
box.style.left = randomX() + "px";
gameLoop();